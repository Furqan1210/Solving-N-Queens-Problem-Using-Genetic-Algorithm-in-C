
/*
******************************************************************************
******************** First Complex Engineering problem ***********************

Written by : ********* Engineer Furqan Shahid *********
Reg no : 2021-MC-64.
date : 1 december 2022
IDE : Visual Studio
gcc : gcc (Rev1, Built by MSYS2 project) 12.2.0
Copyright (C) 2022 Free Software Foundation, Inc.
******************************************************************************
*/

#include <stdio.h>
#include <stdlib.h>  // These libraries are added to create rand() numbers
#include <time.h>    // srand(time(0));
#include <windows.h> // to add colours in terminal

// global variables
int board_size = 9;    // to change the board size
int population_size = 400;   // set the population size
int number_of_generations = 10000; // number of cycles repeating

void random_number(int pop[population_size][board_size]);    // Function decleartion that generates chromosomes
void printing_chromosomes(int pop[population_size][board_size], int attacks[population_size]); // for printing the chromosomes
void number_of_attacks(int pop[population_size][board_size], int attacks[population_size]);    // for calculation the number of attacks in rows and diagonals
void buble_sorting(int pop[population_size][board_size], int attacks[population_size]);  // this function arrange the chromosomes in ascending ordeer
void cross_over(int pop[population_size][board_size]);  // cross over
void mutation(int pop[population_size][board_size]); // to perform mutation
void queen_display(char queen[board_size][board_size], int q[board_size]);
void green(); // to change the terminal output colour to green
void blue();  // to change the terminal output colour to blue

int main()
{
    // loacal variables
    int pop[population_size][board_size]; // for storing the chromosomes
    int attacks[population_size];    // for storing the number of attacks of each chromosome
    char queen[board_size][board_size];   // to display the fittest chromosome
    int q[board_size];

    random_number(pop);  // calling a function to create a random chromosomes as an initial population
    number_of_attacks(pop, attacks); // calculate the number of attacks
    buble_sorting(pop, attacks);     // arranging the each chromosomes in ascending order accroding to theri number of attacks
    // printing_chromosomes(pop, attacks);

    for (int i = 1; i < number_of_generations; i++) // to repeat the genearations
    {

        cross_over(pop);                 // cross over process
        mutation(pop);                   // mutation
        number_of_attacks(pop, attacks); // calculate the number of attacks
        buble_sorting(pop, attacks);     // arranging the each chromosomes in ascending order accroding to theri number of attacks
         printf("Iteration no >> \t%d\n",i);
        // printing_chromosomes(pop, attacks);

        for (int j = 1; j < population_size; j++)
        {
            if (attacks[j] == 0)
            {

                for (int k = 0; k < board_size; k++)
                {
                    for (int n = 0; n < board_size; n++)
                    {
                        if (pop[j][n] == k + 1)
                        {
                            queen[k][n] = 'Q'; // to present queen place
                        }
                        else
                        {
                            queen[k][n] = ' ';
                        }
                    }
                }
            }

            if (attacks[j] == 0)
            {
                blue(); // to change the output colour to blue
                printf("\nThe chromosome is ");
                for (int k = 0; k < board_size; k++)
                {
                    green(); // to change the output colour to green
                    printf("%d", pop[j][k]);
                    q[k] = pop[j][k]; // to save the fiitest chromosome
                    // j=population_size+100;
                    // i = number_of_generations + 100;
                }
                blue(); // to change the output colour to blue
                printf(" in");
                green(); // to change the output colour
                printf(" %d ", i);
                blue(); // to change the output colour to blue
                printf("generations\n");
                queen_display(queen, q);
            }

            if (attacks[j] == 0)
            {

                j = population_size + 100;
                i = number_of_generations + 100;
            }
        }
    }

    return 0;
}

//*******************************************************************************************************
//*******************************************************************************************************
void random_number(int pop[population_size][board_size]) // Funtion for saving random number in a array and make chromosomes
{
    srand(time(0));
    for (int i = 1; i < population_size; i++)
    {
        for (int j = 0; j < board_size; j++)
        {
            pop[i][j] = ((rand() % board_size) + 1);
        }
    }
}
//*******************************************************************************************************
//*******************************************************************************************************

void number_of_attacks(int pop[population_size][board_size], int attacks[population_size])
/* this function checks the number of attacks (fitness) of each chromosome in
rows and also in diagonals*/
{
    int attack = 0; // for calculating the numbers of attacks
    for (int i = 1; i < population_size; i++)
    {
        attack = 0; // for reset the attacks to calculate the number of attacks for next chromosome
        for (int j = 0; j < board_size; j++)
        {
            for (int k = j + 1; k < board_size; k++)
            {
                if (pop[i][j] == pop[i][k]) // condition for checking the number of attacks in rows
                {
                    attack++;
                }
                if (abs(pop[i][j] - pop[i][k]) == abs(j - k)) // condition for checking the number of attacks in diagonals
                {
                    attack++;
                }
            }
        }
        attacks[i] = attack; // storing number of attacks in a array
    }
}
//*******************************************************************************************************
//*******************************************************************************************************
void printing_chromosomes(int pop[population_size][board_size], int attacks[population_size]) // for printing the chromosomes on terminal
{
    for (int i = 1; i < population_size; i++)
    {
        for (int j = 0; j < board_size; j++)
        {
            printf("%d", pop[i][j]); // printing the chromosomes
        }
        printf("\t%d\n", attacks[i]); // printing the number of attacks of chromosome
    }
}
//*******************************************************************************************************
//*******************************************************************************************************
void buble_sorting(int pop[population_size][board_size], int attacks[population_size]) // this function arrange the chromosomes in ascending orders accordidng to the number of attacks
{
    int temp[population_size];
    int a = 0;
    for (int i = 1; i < population_size; i++)
    {

        for (int j = 1; j < population_size; j++)
        {
            if (attacks[j] > attacks[j + 1])
            {
                a = attacks[j];
                attacks[j] = attacks[j + 1];
                attacks[j + 1] = a;
                for (int k = 0; k < board_size; k++)
                {
                    temp[k] = pop[j][k];
                    pop[j][k] = pop[j + 1][k];
                    pop[j + 1][k] = temp[k];
                }
            }
        }
    }
}
//*******************************************************************************************************
//*******************************************************************************************************

void cross_over(int pop[population_size][board_size]) // for cross over
{
    int temp1[4];
    int temp2[4];
    int t = population_size / 2;
    int b = board_size/2;
    for (int i = 1; i < population_size / 2; i = i + 2)
    {
        t = t + 1;
        for (int j = b; j < board_size; j++)
        {
            temp1[j - b] = pop[i][j]; // cross over after 4 index of array
            temp2[j - b] = pop[i + 1][j];
            pop[t][j] = temp2[j - b]; // storing the cross over values
            pop[t + b][j] = temp1[j - b];
        }
    }
}

//*******************************************************************************************************
//*******************************************************************************************************
void mutation(int pop[population_size][board_size]) // For randomly mutation on the random index number of chromosomes
{

    srand(time(0));
    int r1 = 0;
    int r2 = 0;
    for (int i =( population_size/2) ; i < population_size; i++)
    {
        r1 = ((rand() % board_size) + 1);
        r2 = ((rand() % board_size) + 1);
        pop[i][r1 - 1] = r2; // mutation part
    }
}
//*******************************************************************************************************
//*******************************************************************************************************
void blue() // to change the terminal output colour to blue
{
    HANDLE h = GetStdHandle(STD_OUTPUT_HANDLE);
    SetConsoleTextAttribute(h, FOREGROUND_BLUE | FOREGROUND_INTENSITY);
}
//*******************************************************************************************************
//*******************************************************************************************************
void green() // to change the terminal output colour to green
{
    HANDLE h = GetStdHandle(STD_OUTPUT_HANDLE);
    SetConsoleTextAttribute(h, FOREGROUND_RED | FOREGROUND_INTENSITY);
}
//*******************************************************************************************************
//*******************************************************************************************************
void queen_display(char queen[board_size][board_size], int q[board_size])
{
    printf("\n");

    for (int i = 0; i < board_size; i++)
    {

        if (i == 0)
        {
            blue();
            printf("\t|");
            for (int j = 0; j < board_size; j++)
            {
                green();
                printf(" %d ", q[j]);
                blue();
                printf("|");
            }
            printf("\n\n");
        }
        printf("%d\t|", i + 1);
        for (int j = 0; j < board_size; j++)
        {
            green();
            printf(" %c ", queen[i][j]);
            blue();
            printf("|");
        }
        printf("\n");
        if (i < board_size-1)
        {
            blue(); // to change the colour to blue
            printf(" \t|");
            for (int  l = 0; l < board_size; l++)
            {
                printf("---|");
            }
            printf("\n");
        }
    }
    // printf("\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b");
}